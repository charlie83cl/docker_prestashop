<?php
/**
 * 2007-2022 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2022 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

use Paygol\PaygolCore\PaygolApi;

class PaygolPrestaShopConfirmationModuleFrontController extends ModuleFrontController
{
    const PGID_REQUEST = 'PGID';
    const STATUS_REQUEST = 'status';
    const CUSTOM_REQUEST = 'custom';
    const KEY_REQUEST = 'key';

    public function postProcess()
    {
        $paygolTransactionId = pSQL(Tools::getValue(self::PGID_REQUEST));
        $paygolStatus = pSQL(Tools::getValue(self::STATUS_REQUEST));
        $cartIdEncoded = pSQL(Tools::getValue(self::CUSTOM_REQUEST));
        $signature = pSQL(Tools::getValue(self::KEY_REQUEST));

        // Request string is not valid
        $isValid = $this->validateRequest($paygolTransactionId, $paygolStatus, $cartIdEncoded, $signature);
        if (!$isValid) {
            return $this->setTemplate('module:paygolprestashop/views/templates/front/validation-error.tpl');
        }

        // Decode Cart id
        $cartId = $this->base64_url_decode($cartIdEncoded);

        // Payment with error or was cancelled
        if ($paygolStatus !== 'completed') {
            return $this->redirectToErrorPage($cartId);
        }

        // Payment Confirmation
        return $this->confirmTransacction($paygolTransactionId, $cartId);
    }

    // Method for confirm transaction (payment)
    private function confirmTransacction($paygolTransactionId, $cartId)
    {
        try {
            // Get Order by Cart Id
            $orderId = Order::getOrderByCartId((int) $cartId);

            PrestaShopLogger::addLog(
                'Processing Paygol payment ' . $paygolTransactionId . ' for order nº ' . $orderId,
                1,
                null,
                null,
                null,
                true
            );

            // Validate payment against Paygol API
            $paygol = new PaygolApi(
                Configuration::get('TOKEN_SERVICE'),
                Configuration::get('TOKEN_SECRET'),
                Configuration::get('ENVIRONMENT')
            );
            $response = $paygol->getPaymentStatus($paygolTransactionId);

            if (property_exists((object) $response, 'payment')) {
                // Successful validation, validate payment status
                if ($response['payment']['status'] === 'completed') {
                    return $this->redirectToSuccessPage($cartId, $orderId);
                } else {
                    // Payment with error status.
                    PrestaShopLogger::addLog($response['payment'], 3, null, null, null, true);
                    return $this->redirectToErrorPage($cartId);
                }
            } else {
                // Failed validation
                PrestaShopLogger::addLog($response['error'], 3, null, null, null, true);
                return $this->redirectToErrorPage($cartId);
            }
        } catch (Exception $e) {
            PrestaShopLogger::addLog($e->getMessage(), 3, null, null, null, true);
            return $this->redirectToErrorPage($cartId);
        }
    }

    // Method for request validation, based on the hash computation of part the request string.
    private function validateRequest($paygolTransactionId, $paygolStatus, $cartIdEncoded, $signature)
    {
        $secret = Configuration::get('TOKEN_SECRET');

        // Part of the request to be validated
        $query_string =
            self::PGID_REQUEST .
            '=' .
            $paygolTransactionId .
            '&' .
            self::STATUS_REQUEST .
            '=' .
            $paygolStatus .
            '&' .
            self::CUSTOM_REQUEST .
            '=' .
            $cartIdEncoded;

        // Compute signature for comparision
        $computed_signature = $this->computeSignature($query_string, $secret);

        // Request is valid if both signatures are equals.
        return $computed_signature === $signature;
    }

    private function base64_url_decode($b64text)
    {
        return base64_decode(strtr($b64text, '._-', '+/='));
    }

    private function computeSignature($msg, $secret)
    {
        return hash_hmac('sha256', $msg, $secret);
    }

    private function redirectToSuccessPage($cartId, $orderId)
    {
        // The order is marked as paid
        $order = new Order($orderId);
        $PS_OS_PAYMENT = Configuration::get('PS_OS_PAYMENT');
        if ($PS_OS_PAYMENT != $order->getCurrentState()) {
            $order->setCurrentState($PS_OS_PAYMENT);
            $order->save();
        }

        // Get info for user redirect to confirmation page
        $cart = new Cart((int) $cartId);
        $customer = new Customer($cart->id_customer);
        $dataUrl =
            'id_cart=' .
            (int) $cartId .
            '&id_module=' .
            (int) $this->module->id .
            '&id_order=' .
            $orderId .
            '&key=' .
            $customer->secure_key;

        return Tools::redirect('index.php?controller=order-confirmation&' . $dataUrl);
    }

    private function redirectToErrorPage($cartId)
    {
        // Get Order by Cart Id
        $orderId = Order::getOrderByCartId((int) $cartId);
        $order = new Order($orderId);

        $PS_OS_ERROR = Configuration::get('PS_OS_ERROR');
        if ($PS_OS_ERROR != $order->getCurrentState()) {
            $order->setCurrentState($PS_OS_ERROR);
            $order->save();
        }

        $cart = new Cart((int) $cartId);
        // $payment = $order->getOrderPaymentCollection()->getLast();
        $payment = $order->getOrderPaymentCollection();

        $currency = new Currency($cart->id_currency);

        $this->context->smarty->assign([
            'reference' => $order->reference,
            'paygol_transaction_id' => $payment[0]->transaction_id ?? '',
            'total' => Tools::displayPrice($order->total_paid, $currency, false),
            'shop_name' => Configuration::get('PS_SHOP_NAME'),
        ]);

        return $this->setTemplate('module:paygolprestashop/views/templates/front/payment-failed.tpl');
    }
}
