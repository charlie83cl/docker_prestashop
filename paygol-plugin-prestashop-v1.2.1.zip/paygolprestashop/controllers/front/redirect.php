<?php
/**
 * 2007-2022 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2022 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

use Paygol\PaygolCore\PaygolApi;
use Paygol\PaygolCore\Models\Payer;
use Paygol\PaygolCore\Models\RedirectUrls;

class PaygolPrestaShopRedirectModuleFrontController extends ModuleFrontController
{
    /**
     * Do whatever you have to before redirecting the customer on the website of your payment processor.
     */
    public function postProcess()
    {
        /*
         * Oops, an error occured.
         */
        if (Tools::getValue('action') === 'error') {
            return $this->displayError('An error occurred while to redirect the customer to pay. Please, try again later.');
        } else {
            $this->context->smarty->assign([
                'cart_id' => Context::getContext()->cart->id,
                'secure_key' => Context::getContext()->customer->secure_key,
            ]);

            $this->generateTransaction();
            return $this->setTemplate('module:paygolprestashop/views/templates/front/redirect.tpl');
        }
    }

    public function generateTransaction()
    {
        try {
            // Init Paygol Core
            $paygol = new PaygolApi(
                Configuration::get('TOKEN_SERVICE'),
                Configuration::get('TOKEN_SECRET'),
                Configuration::get('ENVIRONMENT')
            );

            // Redirections info
            $redirectUrls = new RedirectUrls();
            $transaction_completed_url = $this->context->link->getModuleLink('paygolprestashop', 'confirmation');
            $transaction_canceled_url = $this->context->link->getModuleLink('paygolprestashop', 'confirmation');
            $redirectUrls->setRedirects($transaction_completed_url, $transaction_canceled_url);
            $paygol->setRedirects($redirectUrls);

            // Order info
            $cart = $this->context->cart;
            $total = (float) Context::getContext()->cart->getOrderTotal(true, Cart::BOTH);
            $currency = new Currency($cart->id_currency);
            $subopt = Tools::getValue('paygol_code');
            $billing = new Address($cart->id_address_invoice);
            $billing_country = new Country($billing->id_country);

            $customer = new Customer($cart->id_customer);
            if (!Validate::isLoadedObject($customer)) {
                // If no customer, return to step 1 (just in case)
                Tools::redirect($this->context->link->getPageLink('order', null, null, 'step=1'));
            }

            // Payer Info
            $payer = new Payer();
            $payer->setFirstName($customer->firstname);
            $payer->setLastName($customer->lastname);
            $payer->setEmail($customer->email);
            $payer->setPhoneNumber($billing->phone);
            $paygol->setPayer($payer);

            // Rest payment info
            $paygol->setCountry($billing_country->iso_code);
            $paygol->setPrice($total, $currency->iso_code);
            $paygol->setPaymentMethod($subopt);
            $paygol->setName('Payment From Paygol');
            $paygol->setCustom($cart->id);

            PrestaShopLogger::addLog(print_r($paygol, 1), 1, null, null, null, true);
            $response = (object) $paygol->createPayment();
            PrestaShopLogger::addLog(print_r($response, 1), 1, null, null, null, true);

            // Selected Payment method url
            if (property_exists((object) $response, 'data')) {
                /**
                 *  Validate and set order with pending payment
                 */
                $this->module->validateOrder(
                    $cart->id,
                    Configuration::get('PS_OS_PAYGOL_PENDING_PAYMENT'),
                    $total,
                    $this->module->displayName,
                    null,
                    ['Paygol transaction id' => $response->data['transaction_id']],
                    (int) $currency->id,
                    false,
                    $customer->secure_key
                );

                $orderId = Order::getOrderByCartId((int) $cart->id);
                $order = new Order($orderId);
                if (isset($order)) {
                    $order->addOrderPayment($total, null, $response->data['transaction_id']);
                    PrestaShopLogger::addLog(
                        'Add Paygol transaction id to order ' . $response->data['transaction_id'],
                        1,
                        null,
                        'Paygol Module',
                        null,
                        true
                    );
                }

                $redirectUrl = $response->data['payment_method_url'];
                Tools::redirectLink($redirectUrl);
            } elseif (property_exists((object) $response, 'error')) {
                // Problem to obtain payment method url.
                $err_msg = 'An error occurred while trying pay with ' . Tools::getValue('paygol_name');
                $err_dsc = $response->error['message'];
                $this->displayError($err_msg, $err_dsc);
            }

            $this->displayError(
                'An error occurred while to redirect the customer to the selected payment method. Please, try again later.'
            );
        } catch (Exception $e) {
            PrestaShopLogger::addLog($e->getMessage(), 3, null, null, null, true);
            $this->displayError(
                'An error occurred while to redirect the customer to the selected payment method. Please, try again later.'
            );
        }
    }

    private function displayError($message, $description = null)
    {
        array_push($this->errors, $this->module->l($message));
        if ($description) {
            array_push($this->errors, $this->module->l($description));
        }

        // Redirect to order, notificating the error.
        $this->redirectWithNotifications($this->context->link->getPageLink('order', null, null, 'step=3'));
    }
}
